
import java.util.Scanner;

public class RESERVATION {
      
    
    
    public int ask_table_num()
    {
        
        return 0;
    }
    
    public int count_number()
    {
        
        return 0;
    }
    
    
}
